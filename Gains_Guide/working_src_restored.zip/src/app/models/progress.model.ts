export interface ProgressMetric {
    date: string;
    weight?: number;
    benchMax?: number;
    squatMax?: number;
    deadliftMax?: number;
  }